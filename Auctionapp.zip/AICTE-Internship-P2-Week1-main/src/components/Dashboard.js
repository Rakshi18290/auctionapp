import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { fetchData } from '../utils/api';

function Dashboard() {
  const [items, setItems] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('authToken');
    if (!token) {
      navigate('/signin');
      return;
    }

    fetchData('auctions').then(setItems).catch(console.error);
  }, [navigate]);

  return (
    <div>
      <h1>Dashboard</h1>
      {items.map((item) => (
        <div key={item.id}>
          <Link to={`/auction/${item.id}`}>{item.name}</Link>
        </div>
      ))}
    </div>
  );
}

export default Dashboard;
