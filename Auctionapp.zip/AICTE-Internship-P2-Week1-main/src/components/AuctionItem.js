import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { fetchData } from '../utils/api';

function AuctionItem() {
  const { id } = useParams();
  const [item, setItem] = useState(null);
  const [bid, setBid] = useState(0);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchData(`auctions/${id}`).then(setItem).catch(console.error);
  }, [id]);

  if (!item) return <p>Loading...</p>;

  return (
    <div>
      <h2>{item.name}</h2>
      <p>{item.description}</p>
      <input
        type="number"
        value={bid}
        onChange={(e) => setBid(e.target.value)}
      />
      <button onClick={() => console.log("Place bid")}>Place Bid</button>
      {message && <p>{message}</p>}
    </div>
  );
}

export default AuctionItem;
